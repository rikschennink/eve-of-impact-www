
SUMMARY
---------------------------------------------------
Game: 
Eve of Impact

Version
1.3.0

Release date:
July 14th, 2012

Appstore:
http://itunes.apple.com/us/app/eve-of-impact/id465159205?ls=1&mt=8

Developer:
Rik Schennink
http://www.rikschennink.nl
http://www.twitter.com/rikschennink
http://www.eveofimpact.com

Contact:
rikschennink@gmail.com

Price:
$0.99

Video:
http://www.youtube.com/watch?v=OqJuuV78Qug


DESCRIPTION
---------------------------------------------------
Blast away at an increasing barrage of asteroids to protect earth from destruction!

Tap your screen to fire missiles at incoming asteroids, watch the immense explosions push away or shatter their targets. Aim carefully because the more missiles explode the more panic is caused and the slower earth's evacuation progresses. The moment you can no longer hold of the barrage of asteroids you witness the end of earth as it has never been shown in any mobile game.

Can you hold of the asteroids long enough, giving mankind a chance to survive?


PRESS
---------------------------------------------------
"Eve of Impact is among the 5 best iPhone games of the week. There’s something both haunting and mesmerizing about this one."
Appolicious

"A beautifully crafted game exhibiting an original idea with detailed lights, explosions and missile trails. I can definitely recommend it." 
AppAdvice ★★★★★

"The graphics, animations, physics, and sounds all come together to create one hell of an immersive experience, especially for an arcade tapping game."
The App Shack ★★★★

"A simple, yet well-done mix of Asteroids and Missile Command that’s perfect for a minute or two of free time."
Slide to Play ★★★★

"Eve of Impact does a magnificent take at saving the earth from impending destruction by asteroids, with its stunning visual effects and simplistic gameplay style."
What's On iPhone ★★★★


HIGHLIGHTS
---------------------------------------------------
● Cinematic lifelike visuals that will pull you in.
● Challenging fast and strategic gameplay.
● Unique gameplay influenced score system.
● Dramatic and thrilling end game animation.
● Online leader boards and achievements.
● Ideal for those short pick up and play sessions.
● Available on both iPhone and iPad.


REQUIRMENTS
---------------------------------------------------
Eve of Impact is a game for the iOS platform, it runs on iPhone 3GS, third-generation iPod Touch, iPad and newer devices.




